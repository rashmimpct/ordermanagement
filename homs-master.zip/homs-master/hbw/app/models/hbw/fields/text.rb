module HBW
  module Fields
    class Text < HBW::Fields::String
    end
  end
end
