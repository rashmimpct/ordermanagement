module HBW
  module Fields
    class User < Ordinary
      self.default_data_type = :string
    end
  end
end
