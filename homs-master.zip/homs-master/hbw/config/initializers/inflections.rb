ActiveSupport::Inflector.inflections(:en) do |inflect|
  inflect.acronym 'HBW'
end
