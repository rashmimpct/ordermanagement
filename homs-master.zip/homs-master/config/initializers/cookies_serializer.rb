Rails.application.config.action_dispatch.cookies_serializer = :json
